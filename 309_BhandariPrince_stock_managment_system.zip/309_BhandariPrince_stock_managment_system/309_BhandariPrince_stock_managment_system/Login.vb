﻿Imports System.Data.OleDb

Public Class Login


    Dim objcon As New path
    
    Private Sub Login_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


        If (objcon.con.State = ConnectionState.Closed) Then objcon.con.Open()
        Pass.UseSystemPasswordChar = True

    End Sub

    Private Sub GunaButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaButton1.Click
        Caccount.Show()
        Me.Hide()
    End Sub

    Private Sub GunaGradientButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnlogin.Click


        
        Dim cmd As OleDbCommand = New OleDbCommand("select * from login where [Username]='" + User.Text + "' and [Password]='" + Pass.Text + "'", objcon.con)
        Dim ad As OleDbDataReader = cmd.ExecuteReader

        If (ad.read() = True) Then
            Me.Hide()
            Home.Show()
            MsgBox("login success" + vbNewLine + "login user : " + User.Text, MsgBoxStyle.Information)
        Else
            MsgBox("login failed", MsgBoxStyle.Critical)
        End If

        Pass.Clear()
        User.Clear()
    End Sub

    Private Sub GunaCheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaCheckBox1.CheckedChanged
        If GunaCheckBox1.Checked = True Then
            Pass.UseSystemPasswordChar = False
        Else
            Pass.UseSystemPasswordChar = True



        End If
    End Sub

End Class
﻿
Public Class Funds

    Private Sub GunaButton1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaButton1.Click
        Me.Close()
    End Sub


    Private Sub GunaButton3_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaButton3.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

   



    Private Sub GunaPictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaPictureBox1.Click
        If GunaPanel2.Width = 175 Then
            Timer2.Enabled = True
        ElseIf GunaPanel2.Width = 60 Then
            Timer1.Enabled = True

        End If
    End Sub

    

    Private Sub Timer1_Tick_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If GunaPanel2.Width >= 175 Then
            Me.Timer1.Enabled = False
        Else
            Me.GunaPanel2.Width = GunaPanel2.Width + 5

        End If
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        If GunaPanel2.Width <= 60 Then
            Me.Timer2.Enabled = False
        Else
            Me.GunaPanel2.Width = GunaPanel2.Width - 5
        End If
    End Sub

   

    Private Sub GunaGradientButton7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton7.Click
        Me.Close()
    End Sub

    Private Sub GunaTileButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaTileButton1.Click

        If GunaTextBox1.Text = "" Then
            MsgBox("Enter Amount", MsgBoxStyle.Exclamation)
            
        End If
    End Sub

    Private Sub GunaTextBox3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaTextBox3.TextChanged
        

    End Sub
    Dim a1 As Integer
    Private Sub GunaTileButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaTileButton2.Click
        

        If GunaTextBox2.Text = "" Then
            MsgBox("Enter Amount", MsgBoxStyle.Exclamation)
            
        Else
            a1 = GunaTextBox2.Text
            If a1 < GunaTextBox1.Text Then
                GunaTextBox3.Text = GunaTextBox1.Text - GunaTextBox2.Text
                GunaTextBox5.Text = GunaTextBox1.Text - GunaTextBox2.Text
            Else
                MsgBox("Invalid Amount", MsgBoxStyle.Exclamation)
                GunaTextBox2.Clear()
            End If

        End If

    End Sub
    Private Sub clear_data()
        GunaTextBox1.Clear()
        GunaTextBox2.Clear()
        GunaTextBox3.Clear()
        GunaTextBox5.Clear()
    End Sub

    Private Sub Funds_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.DoubleClick
        clear_data()
    End Sub

    Private Sub GunaTextBox1_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaTextBox1.DoubleClick
        GunaTextBox1.Clear()
    End Sub

    Private Sub GunaTextBox2_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaTextBox2.DoubleClick
        GunaTextBox2.Clear()
    End Sub

   
    Private Sub Funds_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub GunaGradientButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton1.Click
        Me.Hide()
        Home.Show()
        portfolio.Hide()
        stocksale.Hide()
        Infomation.Hide()
        purchase.Hide()
    End Sub

    Private Sub GunaGradientButton3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton3.Click
        Me.Hide()
        Home.Hide()
        portfolio.Hide()
        stocksale.Hide()
        Infomation.Show()
        purchase.Hide()
    End Sub

    Private Sub GunaGradientButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton2.Click
        Me.Hide()
        Home.Hide()
        portfolio.Show()
        stocksale.Hide()
        Infomation.Hide()
        purchase.Hide()
    End Sub

    Private Sub GunaGradientButton4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton4.Click
        Me.Hide()
        Home.Hide()
        portfolio.Hide()
        stocksale.Hide()
        Infomation.Hide()
        purchase.Show()
    End Sub

    Private Sub GunaGradientButton5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton5.Click
        Me.Hide()
        Home.Hide()
        portfolio.Hide()
        stocksale.Show()
        Infomation.Hide()
        purchase.Hide()
    End Sub

    Private Sub GunaGradientButton6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton6.Click
        Me.Show()
        Home.Hide()
        portfolio.Hide()
        stocksale.Hide()
        Infomation.Hide()
        purchase.Hide()
    End Sub
End Class
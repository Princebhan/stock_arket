﻿
Public Class Home


    Private Sub GunaButton1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaButton1.Click
        Me.Close()
    End Sub

    

    Private Sub GunaButton3_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaButton3.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub



    Private Sub GunaPictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaPictureBox1.Click
        If GunaPanel2.Width = 175 Then
            Timer2.Enabled = True
        ElseIf GunaPanel2.Width = 60 Then
            Timer1.Enabled = True

        End If
    End Sub


    Private Sub Timer1_Tick_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If GunaPanel2.Width >= 175 Then
            Me.Timer1.Enabled = False
        Else
            Me.GunaPanel2.Width = GunaPanel2.Width + 5

        End If
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        If GunaPanel2.Width <= 60 Then
            Me.Timer2.Enabled = False
        Else
            Me.GunaPanel2.Width = GunaPanel2.Width - 5
        End If
    End Sub

    Private Sub GunaGradientButton7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton7.Click
        Me.Close()
    End Sub


    Private Sub GunaGradientButton3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton3.Click


        Me.Hide()
        Infomation.Show()
        purchase.Hide()
        Funds.Hide()
        portfolio.Hide()
        stocksale.Hide()



        'Dim f1 As New Infomation
        'f1.Owner = Me
        'f1.ShowInTaskbar = False
        'f1.ShowDialog()


        'Dim frm As New Infomation
        'frm.MdiParent = Me
        'frm.Show()


    End Sub

    Private Sub GunaGradientButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton2.Click
        Me.Hide()
        Infomation.Hide()
        purchase.Hide()
        Funds.Hide()
        portfolio.Show()
        stocksale.Hide()


        'Dim f2 As New portfolio
        'f2.Owner = Me
        'f2.ShowInTaskbar = False
        'f2.ShowDialog()

        'Dim frm As New portfolio
        'frm.MdiParent = Me
        'frm.Show()
       

    End Sub

    Private Sub GunaGradientButton4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton4.Click
        Me.Hide()
        Infomation.Hide()
        purchase.Show()
        Funds.Hide()
        portfolio.Hide()
        stocksale.Hide()
        'Dim f3 As New purchase
        'f3.Owner = Me
        'f3.ShowInTaskbar = False
        'f3.ShowDialog()
        
        'Dim frm As New purchase
        'frm.MdiParent = Me
        'frm.Show()

    End Sub

    Private Sub GunaGradientButton5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton5.Click
        'Dim f4 As New stocksale
        'f4.Owner = Me
        'f4.ShowInTaskbar = False
        'f4.ShowDialog()
        Me.Hide()
        Infomation.Hide()
        purchase.Hide()
        Funds.Hide()
        portfolio.Hide()
        stocksale.Show()
        'Dim frm As New stocksale
        'frm.MdiParent = Me
        'frm.Show()
       

    End Sub

    Private Sub GunaGradientButton6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton6.Click
        Me.Hide()
        Infomation.Hide()
        purchase.Hide()
        Funds.Show()
        portfolio.Hide()
        stocksale.Hide()
        'Dim f5 As New Funds
        'f5.Owner = Me
        'f5.ShowInTaskbar = False
        'f5.ShowDialog()

        'Dim frm As New Funds
        'frm.MdiParent = Me
        'frm.Show()
        
    End Sub

    Private Sub GunaGradientButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        GunaPanel1.Show()

    End Sub

End Class
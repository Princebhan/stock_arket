﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Funds
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.GunaPanel1 = New Guna.UI.WinForms.GunaPanel()
        Me.GunaButton3 = New Guna.UI.WinForms.GunaButton()
        Me.GunaButton1 = New Guna.UI.WinForms.GunaButton()
        Me.GunaPanel2 = New Guna.UI.WinForms.GunaPanel()
        Me.GunaGradientButton7 = New Guna.UI.WinForms.GunaGradientButton()
        Me.GunaGradientButton6 = New Guna.UI.WinForms.GunaGradientButton()
        Me.GunaGradientButton5 = New Guna.UI.WinForms.GunaGradientButton()
        Me.GunaGradientButton4 = New Guna.UI.WinForms.GunaGradientButton()
        Me.GunaGradientButton2 = New Guna.UI.WinForms.GunaGradientButton()
        Me.GunaGradientButton3 = New Guna.UI.WinForms.GunaGradientButton()
        Me.GunaGradientButton1 = New Guna.UI.WinForms.GunaGradientButton()
        Me.GunaPictureBox2 = New Guna.UI.WinForms.GunaPictureBox()
        Me.GunaPictureBox1 = New Guna.UI.WinForms.GunaPictureBox()
        Me.GunaPanel3 = New Guna.UI.WinForms.GunaPanel()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.GunaLabel1 = New Guna.UI.WinForms.GunaLabel()
        Me.GunaLabel2 = New Guna.UI.WinForms.GunaLabel()
        Me.GunaTextBox1 = New Guna.UI.WinForms.GunaTextBox()
        Me.GunaTextBox2 = New Guna.UI.WinForms.GunaTextBox()
        Me.GunaLabel3 = New Guna.UI.WinForms.GunaLabel()
        Me.GunaLabel4 = New Guna.UI.WinForms.GunaLabel()
        Me.GunaTextBox3 = New Guna.UI.WinForms.GunaTextBox()
        Me.GunaTextBox4 = New Guna.UI.WinForms.GunaTextBox()
        Me.GunaTextBox5 = New Guna.UI.WinForms.GunaTextBox()
        Me.GunaTileButton2 = New Guna.UI.WinForms.GunaTileButton()
        Me.GunaTileButton1 = New Guna.UI.WinForms.GunaTileButton()
        Me.GunaPanel1.SuspendLayout()
        Me.GunaPanel2.SuspendLayout()
        CType(Me.GunaPictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GunaPictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GunaPanel1
        '
        Me.GunaPanel1.BackColor = System.Drawing.Color.Goldenrod
        Me.GunaPanel1.Controls.Add(Me.GunaButton3)
        Me.GunaPanel1.Controls.Add(Me.GunaButton1)
        Me.GunaPanel1.Location = New System.Drawing.Point(2, 3)
        Me.GunaPanel1.Name = "GunaPanel1"
        Me.GunaPanel1.Size = New System.Drawing.Size(834, 44)
        Me.GunaPanel1.TabIndex = 0
        '
        'GunaButton3
        '
        Me.GunaButton3.AnimationHoverSpeed = 0.07!
        Me.GunaButton3.AnimationSpeed = 0.03!
        Me.GunaButton3.BackColor = System.Drawing.Color.OldLace
        Me.GunaButton3.BaseColor = System.Drawing.Color.Goldenrod
        Me.GunaButton3.BorderColor = System.Drawing.Color.Black
        Me.GunaButton3.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaButton3.FocusedColor = System.Drawing.Color.Empty
        Me.GunaButton3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaButton3.ForeColor = System.Drawing.Color.White
        Me.GunaButton3.Image = Global._309_BhandariPrince_stock_managment_system.My.Resources.Resources.mini2
        Me.GunaButton3.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.GunaButton3.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaButton3.Location = New System.Drawing.Point(755, 5)
        Me.GunaButton3.Name = "GunaButton3"
        Me.GunaButton3.OnHoverBaseColor = System.Drawing.Color.Red
        Me.GunaButton3.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaButton3.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaButton3.OnHoverImage = Nothing
        Me.GunaButton3.OnPressedColor = System.Drawing.Color.Black
        Me.GunaButton3.Size = New System.Drawing.Size(35, 39)
        Me.GunaButton3.TabIndex = 2
        '
        'GunaButton1
        '
        Me.GunaButton1.AnimationHoverSpeed = 0.07!
        Me.GunaButton1.AnimationSpeed = 0.03!
        Me.GunaButton1.BackColor = System.Drawing.Color.OldLace
        Me.GunaButton1.BaseColor = System.Drawing.Color.Goldenrod
        Me.GunaButton1.BorderColor = System.Drawing.Color.Black
        Me.GunaButton1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaButton1.FocusedColor = System.Drawing.Color.Empty
        Me.GunaButton1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaButton1.ForeColor = System.Drawing.Color.White
        Me.GunaButton1.Image = Global._309_BhandariPrince_stock_managment_system.My.Resources.Resources.icons8_close_32
        Me.GunaButton1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.GunaButton1.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaButton1.Location = New System.Drawing.Point(796, 5)
        Me.GunaButton1.Name = "GunaButton1"
        Me.GunaButton1.OnHoverBaseColor = System.Drawing.Color.Red
        Me.GunaButton1.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaButton1.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaButton1.OnHoverImage = Nothing
        Me.GunaButton1.OnPressedColor = System.Drawing.Color.Black
        Me.GunaButton1.Size = New System.Drawing.Size(35, 39)
        Me.GunaButton1.TabIndex = 0
        '
        'GunaPanel2
        '
        Me.GunaPanel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(59, Byte), Integer))
        Me.GunaPanel2.Controls.Add(Me.GunaGradientButton7)
        Me.GunaPanel2.Controls.Add(Me.GunaGradientButton6)
        Me.GunaPanel2.Controls.Add(Me.GunaGradientButton5)
        Me.GunaPanel2.Controls.Add(Me.GunaGradientButton4)
        Me.GunaPanel2.Controls.Add(Me.GunaGradientButton2)
        Me.GunaPanel2.Controls.Add(Me.GunaGradientButton3)
        Me.GunaPanel2.Controls.Add(Me.GunaGradientButton1)
        Me.GunaPanel2.Controls.Add(Me.GunaPictureBox2)
        Me.GunaPanel2.Controls.Add(Me.GunaPictureBox1)
        Me.GunaPanel2.Controls.Add(Me.GunaPanel3)
        Me.GunaPanel2.Location = New System.Drawing.Point(2, 46)
        Me.GunaPanel2.Name = "GunaPanel2"
        Me.GunaPanel2.Size = New System.Drawing.Size(175, 426)
        Me.GunaPanel2.TabIndex = 1
        '
        'GunaGradientButton7
        '
        Me.GunaGradientButton7.AnimationHoverSpeed = 0.07!
        Me.GunaGradientButton7.AnimationSpeed = 0.03!
        Me.GunaGradientButton7.BackColor = System.Drawing.Color.Transparent
        Me.GunaGradientButton7.BaseColor1 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.GunaGradientButton7.BaseColor2 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(6, Byte), Integer))
        Me.GunaGradientButton7.BorderColor = System.Drawing.Color.Black
        Me.GunaGradientButton7.BorderSize = 1
        Me.GunaGradientButton7.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaGradientButton7.FocusedColor = System.Drawing.Color.Empty
        Me.GunaGradientButton7.Font = New System.Drawing.Font("Showcard Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaGradientButton7.ForeColor = System.Drawing.Color.Black
        Me.GunaGradientButton7.Image = Global._309_BhandariPrince_stock_managment_system.My.Resources.Resources.logout_logo
        Me.GunaGradientButton7.ImageSize = New System.Drawing.Size(40, 40)
        Me.GunaGradientButton7.Location = New System.Drawing.Point(3, 378)
        Me.GunaGradientButton7.Name = "GunaGradientButton7"
        Me.GunaGradientButton7.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(CType(CType(155, Byte), Integer), CType(CType(145, Byte), Integer), CType(CType(221, Byte), Integer))
        Me.GunaGradientButton7.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaGradientButton7.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaGradientButton7.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaGradientButton7.OnHoverImage = Nothing
        Me.GunaGradientButton7.OnPressedColor = System.Drawing.Color.Black
        Me.GunaGradientButton7.Size = New System.Drawing.Size(172, 36)
        Me.GunaGradientButton7.TabIndex = 15
        Me.GunaGradientButton7.Text = "Log out"
        '
        'GunaGradientButton6
        '
        Me.GunaGradientButton6.AnimationHoverSpeed = 0.07!
        Me.GunaGradientButton6.AnimationSpeed = 0.03!
        Me.GunaGradientButton6.BackColor = System.Drawing.Color.Transparent
        Me.GunaGradientButton6.BaseColor1 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.GunaGradientButton6.BaseColor2 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(6, Byte), Integer))
        Me.GunaGradientButton6.BorderColor = System.Drawing.Color.Black
        Me.GunaGradientButton6.BorderSize = 1
        Me.GunaGradientButton6.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaGradientButton6.FocusedColor = System.Drawing.Color.Empty
        Me.GunaGradientButton6.Font = New System.Drawing.Font("Showcard Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaGradientButton6.ForeColor = System.Drawing.Color.Black
        Me.GunaGradientButton6.Image = Global._309_BhandariPrince_stock_managment_system.My.Resources.Resources.fund1
        Me.GunaGradientButton6.ImageSize = New System.Drawing.Size(40, 40)
        Me.GunaGradientButton6.Location = New System.Drawing.Point(3, 336)
        Me.GunaGradientButton6.Name = "GunaGradientButton6"
        Me.GunaGradientButton6.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(CType(CType(155, Byte), Integer), CType(CType(145, Byte), Integer), CType(CType(221, Byte), Integer))
        Me.GunaGradientButton6.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaGradientButton6.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaGradientButton6.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaGradientButton6.OnHoverImage = Nothing
        Me.GunaGradientButton6.OnPressedColor = System.Drawing.Color.Black
        Me.GunaGradientButton6.Size = New System.Drawing.Size(172, 36)
        Me.GunaGradientButton6.TabIndex = 14
        Me.GunaGradientButton6.Text = "Funds"
        '
        'GunaGradientButton5
        '
        Me.GunaGradientButton5.AnimationHoverSpeed = 0.07!
        Me.GunaGradientButton5.AnimationSpeed = 0.03!
        Me.GunaGradientButton5.BackColor = System.Drawing.Color.Transparent
        Me.GunaGradientButton5.BaseColor1 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.GunaGradientButton5.BaseColor2 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(6, Byte), Integer))
        Me.GunaGradientButton5.BorderColor = System.Drawing.Color.Black
        Me.GunaGradientButton5.BorderSize = 1
        Me.GunaGradientButton5.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaGradientButton5.FocusedColor = System.Drawing.Color.Empty
        Me.GunaGradientButton5.Font = New System.Drawing.Font("Showcard Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaGradientButton5.ForeColor = System.Drawing.Color.Black
        Me.GunaGradientButton5.Image = Global._309_BhandariPrince_stock_managment_system.My.Resources.Resources.sale_logo
        Me.GunaGradientButton5.ImageSize = New System.Drawing.Size(40, 40)
        Me.GunaGradientButton5.Location = New System.Drawing.Point(3, 294)
        Me.GunaGradientButton5.Name = "GunaGradientButton5"
        Me.GunaGradientButton5.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(CType(CType(155, Byte), Integer), CType(CType(145, Byte), Integer), CType(CType(221, Byte), Integer))
        Me.GunaGradientButton5.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaGradientButton5.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaGradientButton5.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaGradientButton5.OnHoverImage = Nothing
        Me.GunaGradientButton5.OnPressedColor = System.Drawing.Color.Black
        Me.GunaGradientButton5.Size = New System.Drawing.Size(172, 36)
        Me.GunaGradientButton5.TabIndex = 13
        Me.GunaGradientButton5.Text = "Sale"
        '
        'GunaGradientButton4
        '
        Me.GunaGradientButton4.AnimationHoverSpeed = 0.07!
        Me.GunaGradientButton4.AnimationSpeed = 0.03!
        Me.GunaGradientButton4.BackColor = System.Drawing.Color.Transparent
        Me.GunaGradientButton4.BaseColor1 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.GunaGradientButton4.BaseColor2 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(6, Byte), Integer))
        Me.GunaGradientButton4.BorderColor = System.Drawing.Color.Black
        Me.GunaGradientButton4.BorderSize = 1
        Me.GunaGradientButton4.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaGradientButton4.FocusedColor = System.Drawing.Color.Empty
        Me.GunaGradientButton4.Font = New System.Drawing.Font("Showcard Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaGradientButton4.ForeColor = System.Drawing.Color.Black
        Me.GunaGradientButton4.Image = Global._309_BhandariPrince_stock_managment_system.My.Resources.Resources.purchase_logo
        Me.GunaGradientButton4.ImageSize = New System.Drawing.Size(43, 43)
        Me.GunaGradientButton4.Location = New System.Drawing.Point(0, 250)
        Me.GunaGradientButton4.Name = "GunaGradientButton4"
        Me.GunaGradientButton4.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(CType(CType(155, Byte), Integer), CType(CType(145, Byte), Integer), CType(CType(221, Byte), Integer))
        Me.GunaGradientButton4.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaGradientButton4.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaGradientButton4.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaGradientButton4.OnHoverImage = Nothing
        Me.GunaGradientButton4.OnPressedColor = System.Drawing.Color.Black
        Me.GunaGradientButton4.Size = New System.Drawing.Size(175, 38)
        Me.GunaGradientButton4.TabIndex = 12
        Me.GunaGradientButton4.Text = "Purchase"
        '
        'GunaGradientButton2
        '
        Me.GunaGradientButton2.AnimationHoverSpeed = 0.07!
        Me.GunaGradientButton2.AnimationSpeed = 0.03!
        Me.GunaGradientButton2.BackColor = System.Drawing.Color.Transparent
        Me.GunaGradientButton2.BaseColor1 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.GunaGradientButton2.BaseColor2 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(6, Byte), Integer))
        Me.GunaGradientButton2.BorderColor = System.Drawing.Color.Black
        Me.GunaGradientButton2.BorderSize = 1
        Me.GunaGradientButton2.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaGradientButton2.FocusedColor = System.Drawing.Color.Empty
        Me.GunaGradientButton2.Font = New System.Drawing.Font("Showcard Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaGradientButton2.ForeColor = System.Drawing.Color.Black
        Me.GunaGradientButton2.Image = Global._309_BhandariPrince_stock_managment_system.My.Resources.Resources.port_logo
        Me.GunaGradientButton2.ImageSize = New System.Drawing.Size(40, 40)
        Me.GunaGradientButton2.Location = New System.Drawing.Point(3, 208)
        Me.GunaGradientButton2.Name = "GunaGradientButton2"
        Me.GunaGradientButton2.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(CType(CType(155, Byte), Integer), CType(CType(145, Byte), Integer), CType(CType(221, Byte), Integer))
        Me.GunaGradientButton2.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaGradientButton2.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaGradientButton2.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaGradientButton2.OnHoverImage = Nothing
        Me.GunaGradientButton2.OnPressedColor = System.Drawing.Color.Black
        Me.GunaGradientButton2.Size = New System.Drawing.Size(172, 36)
        Me.GunaGradientButton2.TabIndex = 11
        Me.GunaGradientButton2.Text = "Portfolio"
        '
        'GunaGradientButton3
        '
        Me.GunaGradientButton3.AnimationHoverSpeed = 0.07!
        Me.GunaGradientButton3.AnimationSpeed = 0.03!
        Me.GunaGradientButton3.BackColor = System.Drawing.Color.Transparent
        Me.GunaGradientButton3.BaseColor1 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.GunaGradientButton3.BaseColor2 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(6, Byte), Integer))
        Me.GunaGradientButton3.BorderColor = System.Drawing.Color.Black
        Me.GunaGradientButton3.BorderSize = 1
        Me.GunaGradientButton3.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaGradientButton3.FocusedColor = System.Drawing.Color.Empty
        Me.GunaGradientButton3.Font = New System.Drawing.Font("Showcard Gothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaGradientButton3.ForeColor = System.Drawing.Color.Black
        Me.GunaGradientButton3.Image = Global._309_BhandariPrince_stock_managment_system.My.Resources.Resources.info_logo
        Me.GunaGradientButton3.ImageSize = New System.Drawing.Size(40, 40)
        Me.GunaGradientButton3.Location = New System.Drawing.Point(3, 166)
        Me.GunaGradientButton3.Name = "GunaGradientButton3"
        Me.GunaGradientButton3.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(CType(CType(155, Byte), Integer), CType(CType(145, Byte), Integer), CType(CType(221, Byte), Integer))
        Me.GunaGradientButton3.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaGradientButton3.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaGradientButton3.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaGradientButton3.OnHoverImage = Nothing
        Me.GunaGradientButton3.OnPressedColor = System.Drawing.Color.Black
        Me.GunaGradientButton3.Size = New System.Drawing.Size(172, 36)
        Me.GunaGradientButton3.TabIndex = 10
        Me.GunaGradientButton3.Text = "Information"
        '
        'GunaGradientButton1
        '
        Me.GunaGradientButton1.AnimationHoverSpeed = 0.07!
        Me.GunaGradientButton1.AnimationSpeed = 0.03!
        Me.GunaGradientButton1.BackColor = System.Drawing.Color.Transparent
        Me.GunaGradientButton1.BaseColor1 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(51, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.GunaGradientButton1.BaseColor2 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(121, Byte), Integer), CType(CType(6, Byte), Integer))
        Me.GunaGradientButton1.BorderColor = System.Drawing.Color.Black
        Me.GunaGradientButton1.BorderSize = 1
        Me.GunaGradientButton1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaGradientButton1.FocusedColor = System.Drawing.Color.Empty
        Me.GunaGradientButton1.Font = New System.Drawing.Font("Showcard Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaGradientButton1.ForeColor = System.Drawing.Color.Black
        Me.GunaGradientButton1.Image = Global._309_BhandariPrince_stock_managment_system.My.Resources.Resources.home_logo4
        Me.GunaGradientButton1.ImageSize = New System.Drawing.Size(40, 40)
        Me.GunaGradientButton1.Location = New System.Drawing.Point(3, 124)
        Me.GunaGradientButton1.Name = "GunaGradientButton1"
        Me.GunaGradientButton1.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(CType(CType(155, Byte), Integer), CType(CType(145, Byte), Integer), CType(CType(221, Byte), Integer))
        Me.GunaGradientButton1.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaGradientButton1.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaGradientButton1.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaGradientButton1.OnHoverImage = Nothing
        Me.GunaGradientButton1.OnPressedColor = System.Drawing.Color.Black
        Me.GunaGradientButton1.Size = New System.Drawing.Size(172, 36)
        Me.GunaGradientButton1.TabIndex = 9
        Me.GunaGradientButton1.Text = "Home"
        Me.GunaGradientButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GunaPictureBox2
        '
        Me.GunaPictureBox2.BaseColor = System.Drawing.Color.White
        Me.GunaPictureBox2.Image = Global._309_BhandariPrince_stock_managment_system.My.Resources.Resources.mylogo4
        Me.GunaPictureBox2.Location = New System.Drawing.Point(3, 51)
        Me.GunaPictureBox2.Name = "GunaPictureBox2"
        Me.GunaPictureBox2.Size = New System.Drawing.Size(172, 57)
        Me.GunaPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.GunaPictureBox2.TabIndex = 4
        Me.GunaPictureBox2.TabStop = False
        '
        'GunaPictureBox1
        '
        Me.GunaPictureBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GunaPictureBox1.BaseColor = System.Drawing.Color.White
        Me.GunaPictureBox1.Image = Global._309_BhandariPrince_stock_managment_system.My.Resources.Resources.logo_menu
        Me.GunaPictureBox1.Location = New System.Drawing.Point(131, 3)
        Me.GunaPictureBox1.Name = "GunaPictureBox1"
        Me.GunaPictureBox1.Size = New System.Drawing.Size(44, 42)
        Me.GunaPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.GunaPictureBox1.TabIndex = 3
        Me.GunaPictureBox1.TabStop = False
        '
        'GunaPanel3
        '
        Me.GunaPanel3.Location = New System.Drawing.Point(173, 7)
        Me.GunaPanel3.Name = "GunaPanel3"
        Me.GunaPanel3.Size = New System.Drawing.Size(661, 419)
        Me.GunaPanel3.TabIndex = 2
        '
        'Timer1
        '
        '
        'Timer2
        '
        '
        'GunaLabel1
        '
        Me.GunaLabel1.AutoSize = True
        Me.GunaLabel1.Font = New System.Drawing.Font("Showcard Gothic", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaLabel1.ForeColor = System.Drawing.Color.Olive
        Me.GunaLabel1.Location = New System.Drawing.Point(344, 61)
        Me.GunaLabel1.Name = "GunaLabel1"
        Me.GunaLabel1.Size = New System.Drawing.Size(218, 30)
        Me.GunaLabel1.TabIndex = 2
        Me.GunaLabel1.Text = "Available Fund"
        '
        'GunaLabel2
        '
        Me.GunaLabel2.AutoSize = True
        Me.GunaLabel2.Font = New System.Drawing.Font("Castellar", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaLabel2.ForeColor = System.Drawing.Color.Blue
        Me.GunaLabel2.Location = New System.Drawing.Point(220, 187)
        Me.GunaLabel2.Name = "GunaLabel2"
        Me.GunaLabel2.Size = New System.Drawing.Size(115, 19)
        Me.GunaLabel2.TabIndex = 3
        Me.GunaLabel2.Text = "Add Fund"
        '
        'GunaTextBox1
        '
        Me.GunaTextBox1.BaseColor = System.Drawing.SystemColors.Control
        Me.GunaTextBox1.BorderColor = System.Drawing.Color.Silver
        Me.GunaTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.GunaTextBox1.FocusedBaseColor = System.Drawing.Color.White
        Me.GunaTextBox1.FocusedBorderColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaTextBox1.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.GunaTextBox1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaTextBox1.ForeColor = System.Drawing.Color.Black
        Me.GunaTextBox1.Location = New System.Drawing.Point(456, 187)
        Me.GunaTextBox1.Name = "GunaTextBox1"
        Me.GunaTextBox1.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.GunaTextBox1.SelectedText = ""
        Me.GunaTextBox1.Size = New System.Drawing.Size(160, 32)
        Me.GunaTextBox1.TabIndex = 4
        '
        'GunaTextBox2
        '
        Me.GunaTextBox2.BaseColor = System.Drawing.SystemColors.Control
        Me.GunaTextBox2.BorderColor = System.Drawing.Color.Silver
        Me.GunaTextBox2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.GunaTextBox2.FocusedBaseColor = System.Drawing.Color.White
        Me.GunaTextBox2.FocusedBorderColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaTextBox2.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.GunaTextBox2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaTextBox2.ForeColor = System.Drawing.Color.Black
        Me.GunaTextBox2.Location = New System.Drawing.Point(456, 254)
        Me.GunaTextBox2.Name = "GunaTextBox2"
        Me.GunaTextBox2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.GunaTextBox2.SelectedText = ""
        Me.GunaTextBox2.Size = New System.Drawing.Size(160, 32)
        Me.GunaTextBox2.TabIndex = 5
        '
        'GunaLabel3
        '
        Me.GunaLabel3.AutoSize = True
        Me.GunaLabel3.Font = New System.Drawing.Font("Castellar", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaLabel3.ForeColor = System.Drawing.Color.Blue
        Me.GunaLabel3.Location = New System.Drawing.Point(220, 254)
        Me.GunaLabel3.Name = "GunaLabel3"
        Me.GunaLabel3.Size = New System.Drawing.Size(186, 19)
        Me.GunaLabel3.TabIndex = 6
        Me.GunaLabel3.Text = "Withdraw Fund"
        '
        'GunaLabel4
        '
        Me.GunaLabel4.AutoSize = True
        Me.GunaLabel4.Font = New System.Drawing.Font("Castellar", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaLabel4.ForeColor = System.Drawing.Color.Blue
        Me.GunaLabel4.Location = New System.Drawing.Point(220, 315)
        Me.GunaLabel4.Name = "GunaLabel4"
        Me.GunaLabel4.Size = New System.Drawing.Size(137, 19)
        Me.GunaLabel4.TabIndex = 7
        Me.GunaLabel4.Text = "Total fund"
        '
        'GunaTextBox3
        '
        Me.GunaTextBox3.BaseColor = System.Drawing.SystemColors.Control
        Me.GunaTextBox3.BorderColor = System.Drawing.Color.Silver
        Me.GunaTextBox3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.GunaTextBox3.FocusedBaseColor = System.Drawing.Color.White
        Me.GunaTextBox3.FocusedBorderColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaTextBox3.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.GunaTextBox3.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaTextBox3.ForeColor = System.Drawing.Color.Black
        Me.GunaTextBox3.Location = New System.Drawing.Point(456, 315)
        Me.GunaTextBox3.Name = "GunaTextBox3"
        Me.GunaTextBox3.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.GunaTextBox3.SelectedText = ""
        Me.GunaTextBox3.Size = New System.Drawing.Size(160, 32)
        Me.GunaTextBox3.TabIndex = 8
        '
        'GunaTextBox4
        '
        Me.GunaTextBox4.BaseColor = System.Drawing.SystemColors.Control
        Me.GunaTextBox4.BorderColor = System.Drawing.SystemColors.Control
        Me.GunaTextBox4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.GunaTextBox4.FocusedBaseColor = System.Drawing.Color.White
        Me.GunaTextBox4.FocusedBorderColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaTextBox4.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.GunaTextBox4.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaTextBox4.ForeColor = System.Drawing.Color.Black
        Me.GunaTextBox4.Location = New System.Drawing.Point(393, 125)
        Me.GunaTextBox4.Name = "GunaTextBox4"
        Me.GunaTextBox4.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.GunaTextBox4.SelectedText = ""
        Me.GunaTextBox4.Size = New System.Drawing.Size(48, 42)
        Me.GunaTextBox4.TabIndex = 12
        Me.GunaTextBox4.Text = "RS."
        '
        'GunaTextBox5
        '
        Me.GunaTextBox5.BaseColor = System.Drawing.SystemColors.Control
        Me.GunaTextBox5.BorderColor = System.Drawing.SystemColors.Control
        Me.GunaTextBox5.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.GunaTextBox5.FocusedBaseColor = System.Drawing.Color.White
        Me.GunaTextBox5.FocusedBorderColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaTextBox5.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.GunaTextBox5.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaTextBox5.ForeColor = System.Drawing.Color.Black
        Me.GunaTextBox5.Location = New System.Drawing.Point(435, 128)
        Me.GunaTextBox5.Name = "GunaTextBox5"
        Me.GunaTextBox5.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.GunaTextBox5.SelectedText = ""
        Me.GunaTextBox5.Size = New System.Drawing.Size(138, 36)
        Me.GunaTextBox5.TabIndex = 13
        '
        'GunaTileButton2
        '
        Me.GunaTileButton2.AnimationHoverSpeed = 0.07!
        Me.GunaTileButton2.AnimationSpeed = 0.03!
        Me.GunaTileButton2.BackColor = System.Drawing.Color.Transparent
        Me.GunaTileButton2.BaseColor = System.Drawing.Color.DarkOliveGreen
        Me.GunaTileButton2.BorderColor = System.Drawing.Color.Black
        Me.GunaTileButton2.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaTileButton2.FocusedColor = System.Drawing.Color.Empty
        Me.GunaTileButton2.Font = New System.Drawing.Font("Segoe UI Light", 15.75!)
        Me.GunaTileButton2.ForeColor = System.Drawing.Color.White
        Me.GunaTileButton2.Image = Global._309_BhandariPrince_stock_managment_system.My.Resources.Resources.add_fund
        Me.GunaTileButton2.ImageSize = New System.Drawing.Size(30, 30)
        Me.GunaTileButton2.Location = New System.Drawing.Point(297, 395)
        Me.GunaTileButton2.Name = "GunaTileButton2"
        Me.GunaTileButton2.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(151, Byte), Integer), CType(CType(143, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaTileButton2.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaTileButton2.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaTileButton2.OnHoverImage = Nothing
        Me.GunaTileButton2.OnPressedColor = System.Drawing.Color.Black
        Me.GunaTileButton2.Radius = 3
        Me.GunaTileButton2.Size = New System.Drawing.Size(162, 65)
        Me.GunaTileButton2.TabIndex = 11
        Me.GunaTileButton2.Text = "Withdraw Fund"
        '
        'GunaTileButton1
        '
        Me.GunaTileButton1.AnimationHoverSpeed = 0.07!
        Me.GunaTileButton1.AnimationSpeed = 0.03!
        Me.GunaTileButton1.BackColor = System.Drawing.Color.Transparent
        Me.GunaTileButton1.BaseColor = System.Drawing.Color.Sienna
        Me.GunaTileButton1.BorderColor = System.Drawing.Color.Black
        Me.GunaTileButton1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaTileButton1.FocusedColor = System.Drawing.Color.Empty
        Me.GunaTileButton1.Font = New System.Drawing.Font("Segoe UI Light", 15.75!)
        Me.GunaTileButton1.ForeColor = System.Drawing.Color.White
        Me.GunaTileButton1.Image = Global._309_BhandariPrince_stock_managment_system.My.Resources.Resources.withdraw_fund
        Me.GunaTileButton1.ImageSize = New System.Drawing.Size(30, 30)
        Me.GunaTileButton1.Location = New System.Drawing.Point(514, 395)
        Me.GunaTileButton1.Name = "GunaTileButton1"
        Me.GunaTileButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(151, Byte), Integer), CType(CType(143, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaTileButton1.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaTileButton1.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaTileButton1.OnHoverImage = Nothing
        Me.GunaTileButton1.OnPressedColor = System.Drawing.Color.Black
        Me.GunaTileButton1.Radius = 3
        Me.GunaTileButton1.Size = New System.Drawing.Size(162, 65)
        Me.GunaTileButton1.TabIndex = 10
        Me.GunaTileButton1.Text = "Add Fund"
        '
        'Funds
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(838, 472)
        Me.Controls.Add(Me.GunaTextBox5)
        Me.Controls.Add(Me.GunaTextBox4)
        Me.Controls.Add(Me.GunaTileButton2)
        Me.Controls.Add(Me.GunaTileButton1)
        Me.Controls.Add(Me.GunaTextBox3)
        Me.Controls.Add(Me.GunaLabel4)
        Me.Controls.Add(Me.GunaLabel3)
        Me.Controls.Add(Me.GunaTextBox2)
        Me.Controls.Add(Me.GunaTextBox1)
        Me.Controls.Add(Me.GunaLabel2)
        Me.Controls.Add(Me.GunaLabel1)
        Me.Controls.Add(Me.GunaPanel2)
        Me.Controls.Add(Me.GunaPanel1)
        Me.ForeColor = System.Drawing.Color.CadetBlue
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Funds"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Home"
        Me.GunaPanel1.ResumeLayout(False)
        Me.GunaPanel2.ResumeLayout(False)
        CType(Me.GunaPictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GunaPictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GunaPanel1 As Guna.UI.WinForms.GunaPanel
    Friend WithEvents GunaPanel2 As Guna.UI.WinForms.GunaPanel
    Friend WithEvents GunaPanel3 As Guna.UI.WinForms.GunaPanel
    Friend WithEvents GunaButton1 As Guna.UI.WinForms.GunaButton
    Friend WithEvents GunaButton3 As Guna.UI.WinForms.GunaButton
    Friend WithEvents GunaPictureBox1 As Guna.UI.WinForms.GunaPictureBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents GunaPictureBox2 As Guna.UI.WinForms.GunaPictureBox
    Friend WithEvents GunaGradientButton1 As Guna.UI.WinForms.GunaGradientButton
    Friend WithEvents GunaGradientButton3 As Guna.UI.WinForms.GunaGradientButton
    Friend WithEvents GunaGradientButton2 As Guna.UI.WinForms.GunaGradientButton
    Friend WithEvents GunaGradientButton4 As Guna.UI.WinForms.GunaGradientButton
    Friend WithEvents GunaGradientButton5 As Guna.UI.WinForms.GunaGradientButton
    Friend WithEvents GunaGradientButton6 As Guna.UI.WinForms.GunaGradientButton
    Friend WithEvents GunaGradientButton7 As Guna.UI.WinForms.GunaGradientButton
    Friend WithEvents GunaLabel1 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents GunaLabel2 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents GunaTextBox1 As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents GunaTextBox2 As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents GunaLabel3 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents GunaLabel4 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents GunaTextBox3 As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents GunaTileButton1 As Guna.UI.WinForms.GunaTileButton
    Friend WithEvents GunaTileButton2 As Guna.UI.WinForms.GunaTileButton
    Friend WithEvents GunaTextBox4 As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents GunaTextBox5 As Guna.UI.WinForms.GunaTextBox
End Class

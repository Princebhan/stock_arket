﻿Imports System.Data.OleDb

Public Class Caccount

    Dim cmd As OleDbCommand
    Dim objcon As New path


    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs)
        Login.Show()

    End Sub

    Private Sub Caccount_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If (objcon.con.State = ConnectionState.Closed) Then objcon.con.Open()
        Password.UseSystemPasswordChar = True

    End Sub

    Private Sub GunaLinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles GunaLinkLabel1.LinkClicked
        Login.Show()
        Me.Hide()
    End Sub

    Sub save()

        Try


            Dim i As New Integer
            cmd = New OleDbCommand("insert into login values ('" + Username.Text + "','" + Password.Text + "')", objcon.con)


            i = cmd.ExecuteNonQuery()

            If i > 0 Then
                MsgBox("New User Register Success !", vbInformation)
            Else
                MsgBox("New User Register Failed !", vbCritical)
            End If


        Catch ex As Exception
            MsgBox(ex.Message)

        End Try

        Login.Show()
        Me.Hide()

    End Sub

    Private Sub GunaGradientButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton1.Click
        save()

    End Sub

    Private Sub GunaCheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaCheckBox1.CheckedChanged
        If GunaCheckBox1.Checked = True Then
            Password.UseSystemPasswordChar = False
        Else
            Password.UseSystemPasswordChar = True
        End If
    End Sub

    
End Class

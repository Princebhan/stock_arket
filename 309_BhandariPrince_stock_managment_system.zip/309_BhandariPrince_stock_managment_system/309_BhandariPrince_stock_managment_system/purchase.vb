﻿Imports System.Data.OleDb
Public Class purchase

    Dim cmd As OleDbCommand

    Dim da As OleDbDataAdapter

    Dim ds As DataSet

    Dim objcon As New path



    
    Private Sub load_data()
        

        Dim objcon As New path

        da = New OleDbDataAdapter("select * from Info", objcon.con)
        ds = New DataSet()

        da.Fill(ds)
        GunaDataGridView1.DataSource = ds.Tables(0)



    End Sub



    Private Sub Home_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        load_data()
    End Sub

    Private Sub GunaButton1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaButton1.Click
        Me.Close()
    End Sub


    Private Sub GunaButton3_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaButton3.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub



    Private Sub GunaPictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaPictureBox1.Click
        If GunaPanel2.Width = 175 Then
            Timer2.Enabled = True
        ElseIf GunaPanel2.Width = 60 Then
            Timer1.Enabled = True

        End If
    End Sub

   

    Private Sub Timer1_Tick_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If GunaPanel2.Width >= 175 Then
            Me.Timer1.Enabled = False
        Else
            Me.GunaPanel2.Width = GunaPanel2.Width + 5

        End If
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        If GunaPanel2.Width <= 60 Then
            Me.Timer2.Enabled = False
        Else
            Me.GunaPanel2.Width = GunaPanel2.Width - 5
        End If
    End Sub

   

    Private Sub GunaGradientButton7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton7.Click
        Me.Close()
    End Sub

    Dim x As Integer
    Private Sub GunaGradientButton8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton8.Click
        x = GunaDataGridView1.CurrentRow.Cells(4).Value

       
        If (objcon.con.State = ConnectionState.Closed) Then objcon.con.Open()

        If GunaTextBox1.Text = "" Then
            MsgBox("Select The Share", MsgBoxStyle.OkCancel)
        ElseIf  GunaTextBox5.Text = "" Then
            MsgBox("Enter Quantity", MsgBoxStyle.OkCancel)

        ElseIf x < GunaTextBox5.Text Then

            MsgBox("Quantity, Must Be Less Than Total Quantity", MsgBoxStyle.Exclamation)
        Else

            MsgBox("Successfully Purchased", MsgBoxStyle.Information)
            cmd = New OleDbCommand("insert into purch values (" + GunaTextBox1.Text + "," + GunaTextBox2.Text + ",'" + GunaTextBox3.Text + "','" + GunaTextBox4.Text + "','" + GunaTextBox5.Text + "','" + DateTimePicker1.Value + "')", objcon.con)
            cmd.ExecuteNonQuery()
            GunaTextBox1.Clear()
            GunaTextBox2.Clear()
            GunaTextBox3.Clear()
            GunaTextBox4.Clear()
            GunaTextBox5.Clear()
        End If


        load_data()
    End Sub
    

    Private Sub GunaDataGridView1_CellClick_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles GunaDataGridView1.CellClick
        GunaTextBox1.Text = GunaDataGridView1.CurrentRow.Cells(0).Value
        GunaTextBox2.Text = GunaDataGridView1.CurrentRow.Cells(1).Value
        GunaTextBox3.Text = GunaDataGridView1.CurrentRow.Cells(2).Value.ToString
        GunaTextBox4.Text = GunaDataGridView1.CurrentRow.Cells(3).Value

    End Sub

    Private Sub GunaGradientButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton1.Click
        Me.Hide()
        Home.Show()
        portfolio.Hide()
        Funds.Hide()
        Infomation.Hide()
        stocksale.Hide()
    End Sub

    Private Sub GunaGradientButton3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton3.Click
        Me.Hide()
        Home.Hide()
        portfolio.Hide()
        Funds.Hide()
        Infomation.Show()
        stocksale.Hide()
    End Sub

    Private Sub GunaGradientButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton2.Click
        Me.Hide()
        Home.Hide()
        portfolio.Show()
        Funds.Hide()
        Infomation.Hide()
        stocksale.Hide()
    End Sub

    Private Sub GunaGradientButton4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton4.Click
        Me.Show()
        Home.Hide()
        portfolio.Hide()
        Funds.Hide()
        Infomation.Hide()
        stocksale.Hide()
    End Sub

    Private Sub GunaGradientButton5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton5.Click
        Me.Hide()
        Home.Hide()
        portfolio.Hide()
        Funds.Hide()
        Infomation.Hide()
        stocksale.Show()
    End Sub

    Private Sub GunaGradientButton6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton6.Click
        Me.Hide()
        Home.Hide()
        portfolio.Hide()
        Funds.Show()
        Infomation.Hide()
        stocksale.Hide()
    End Sub
End Class
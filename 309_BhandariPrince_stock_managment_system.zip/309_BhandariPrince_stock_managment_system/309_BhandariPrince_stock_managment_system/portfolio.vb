﻿Imports System.Data.OleDb
Public Class portfolio


    Dim cmd As OleDbCommand

    Dim da As OleDbDataAdapter

    Dim ds As DataSet


    Private Sub Home_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        data_load()
       
    End Sub

    Private Sub data_load()
        Dim objcon As New path
        If (objcon.con.State = ConnectionState.Closed) Then objcon.con.Open()

        da = New OleDbDataAdapter("select * from purch", objcon.con)
        ds = New DataSet()

        da.Fill(ds)
        GunaDataGridView1.DataSource = ds.Tables(0)

    End Sub

    Private Sub GunaButton1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaButton1.Click
        Me.Close()
    End Sub


    Private Sub GunaButton3_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaButton3.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub





    Private Sub GunaPictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaPictureBox1.Click
        If GunaPanel2.Width = 175 Then
            Timer2.Enabled = True
        ElseIf GunaPanel2.Width = 60 Then
            Timer1.Enabled = True

        End If
    End Sub



    Private Sub Timer1_Tick_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If GunaPanel2.Width >= 175 Then
            Me.Timer1.Enabled = False
        Else
            Me.GunaPanel2.Width = GunaPanel2.Width + 5

        End If
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        If GunaPanel2.Width <= 60 Then
            Me.Timer2.Enabled = False
        Else
            Me.GunaPanel2.Width = GunaPanel2.Width - 5
        End If
    End Sub



    Private Sub GunaGradientButton7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton7.Click
        Me.Close()
    End Sub

    Private Sub GunaGradientButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton2.Click
        Me.Show()
        Home.Hide()
        purchase.Hide()
        Funds.Hide()
        Infomation.Hide()
        stocksale.Hide()
    End Sub

    Private Sub GunaGradientButton3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton3.Click
        Me.Hide()
        Home.Hide()
        purchase.Hide()
        Funds.Hide()
        Infomation.Show()
        stocksale.Hide()
    End Sub

    Private Sub GunaGradientButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton1.Click
        Me.Hide()
        Home.Show()
        purchase.Hide()
        Funds.Hide()
        Infomation.Hide()
        stocksale.Hide()
    End Sub

    Private Sub GunaGradientButton4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton4.Click
        Me.Hide()
        Home.Hide()
        purchase.Show()
        Funds.Hide()
        Infomation.Hide()
        stocksale.Hide()
    End Sub

    Private Sub GunaGradientButton5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton5.Click
        Me.Hide()
        Home.Hide()
        purchase.Hide()
        Funds.Hide()
        Infomation.Hide()
        stocksale.Show()
    End Sub

    Private Sub GunaGradientButton6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton6.Click
        Me.Hide()
        Home.Hide()
        purchase.Hide()
        Funds.Hide()
        Infomation.Hide()
        stocksale.Show()
    End Sub

    Private Sub GunaDataGridView1_CellDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles GunaDataGridView1.CellDoubleClick
        data_load()
    End Sub
End Class
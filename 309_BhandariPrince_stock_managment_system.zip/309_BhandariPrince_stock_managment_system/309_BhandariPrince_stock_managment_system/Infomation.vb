﻿Imports System.Data.OleDb

Public Class Infomation

    Dim cmd As OleDbCommand

    Dim da As OleDbDataAdapter

    Dim ds As DataSet

    Dim objcon As New path

    Private Sub load_data()
        
        Dim objcon As New path

        If (objcon.con.State = ConnectionState.Closed) Then objcon.con.Open()


        da = New OleDbDataAdapter("select * from Info", objcon.con)
        ds = New DataSet()

        da.Fill(ds)
        GunaDataGridView1.DataSource = ds.Tables(0)


    End Sub
    Private Sub Home_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        load_data()
    End Sub

   

    Private Sub GunaButton1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaButton1.Click
        Me.Close()
    End Sub

    

    Private Sub GunaButton3_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaButton3.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

  



    Private Sub GunaPictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaPictureBox1.Click
        If GunaPanel2.Width = 175 Then
            Timer2.Enabled = True
        ElseIf GunaPanel2.Width = 60 Then
            Timer1.Enabled = True

        End If
    End Sub

    

    Private Sub Timer1_Tick_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If GunaPanel2.Width >= 175 Then
            Me.Timer1.Enabled = False
        Else
            Me.GunaPanel2.Width = GunaPanel2.Width + 5

        End If
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        If GunaPanel2.Width <= 60 Then
            Me.Timer2.Enabled = False
        Else
            Me.GunaPanel2.Width = GunaPanel2.Width - 5
        End If
    End Sub

   

    Private Sub GunaGradientButton7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton7.Click
        Me.Close()
    End Sub

   


    Private Sub btnInsert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInsert.Click
       
        If (objcon.con.State = ConnectionState.Closed) Then objcon.con.Open()

        If GunaTextBox1.Text = "" Then
            MsgBox("Enter the Detail", MsgBoxStyle.Exclamation)
        Else
            cmd = New OleDbCommand("insert into Info values (" + GunaTextBox1.Text + "," + GunaTextBox2.Text + ",'" + GunaTextBox3.Text + "','" + GunaTextBox4.Text + "','" + GunaTextBox5.Text + "','" + DateTimePicker1.Value + "','" + RichTextBox1.Text + "')", objcon.con)
            cmd.ExecuteNonQuery()

            MsgBox("Inserted...")
        End If
        GunaTextBox1.Clear()
        GunaTextBox2.Clear()
        GunaTextBox3.Clear()
        GunaTextBox4.Clear()
        GunaTextBox5.Clear()
        RichTextBox1.Clear()

        load_data()
    End Sub



    Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click

       
        If (objcon.con.State = ConnectionState.Closed) Then objcon.con.Open()

        GunaTextBox1.Clear()
        GunaTextBox2.Clear()
        GunaTextBox3.Clear()
        GunaTextBox4.Clear()
        GunaTextBox5.Clear()

        If GunaTextBox1.Text = "" Then
            MsgBox("Select The Share", MsgBoxStyle.Exclamation)
       
        End If

    End Sub

   

    Private Sub GunaDataGridView1_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles GunaDataGridView1.CellClick
        MsgBox("Data Filled In Stock Description", MsgBoxStyle.Information)
        GunaTextBox1.Text = GunaDataGridView1.CurrentRow.Cells(0).Value
        GunaTextBox2.Text = GunaDataGridView1.CurrentRow.Cells(1).Value
        GunaTextBox3.Text = GunaDataGridView1.CurrentRow.Cells(2).Value.ToString
        GunaTextBox4.Text = GunaDataGridView1.CurrentRow.Cells(3).Value
        GunaTextBox5.Text = GunaDataGridView1.CurrentRow.Cells(4).Value
        RichTextBox1.Text = GunaDataGridView1.CurrentRow.Cells(6).Value.ToString
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
       
        If (objcon.con.State = ConnectionState.Closed) Then objcon.con.Open()


        If GunaTextBox1.Text = "" Then
            MsgBox("Select The Share", MsgBoxStyle.Exclamation)
        Else


            Dim cmd As OleDbCommand
            cmd = New OleDbCommand("delete from Info where Sno=" + GunaTextBox1.Text + "", objcon.con)
            cmd.ExecuteNonQuery()
            MsgBox("Successfully Deleted", MsgBoxStyle.Information)
        End If

        'cn.Close()


        GunaTextBox1.Clear()
        GunaTextBox2.Clear()
        GunaTextBox3.Clear()
        GunaTextBox4.Clear()
        GunaTextBox5.Clear()
        RichTextBox1.Clear()

        load_data()

    End Sub


    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
       
        If (objcon.con.State = ConnectionState.Closed) Then objcon.con.Open()

        If GunaTextBox1.Text = "" Then
            MsgBox("Select The Share", MsgBoxStyle.Exclamation)
        Else


            Dim sqlUpdate As String
            Dim sqlUpdatePass As DialogResult
            sqlUpdate = "UPDATE Info SET [Stock Id] = '" & GunaTextBox2.Text & "',[Stock Name] = '" & GunaTextBox3.Text & "',[Price] = " & GunaTextBox4.Text & ",[Qty] = " & GunaTextBox5.Text & " WHERE [Sno] =" & GunaTextBox1.Text & ""


            cmd = New OleDbCommand(sqlUpdate, objcon.con)
            Try
                sqlUpdatePass = MessageBox.Show("Are you sure to save this changes?", "Save changes?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                If sqlUpdatePass = vbYes Then
                    cmd.ExecuteNonQuery()
                    MsgBox("Changes are now saved", MsgBoxStyle.Information, "New Update has been set.")
                    load_data()

                Else
                    Exit Sub
                End If
            Catch ex As Exception
                MsgBox("Could not perform this task because " & ex.Message, MsgBoxStyle.Exclamation, "Error")
            End Try
        End If


    End Sub

    Private Sub GunaGradientButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton1.Click
        Home.Show()
        Me.Hide()
        purchase.Hide()
        Funds.Hide()
        portfolio.Hide()
        stocksale.Hide()
    End Sub

    Private Sub GunaGradientButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton2.Click
        Me.Hide()
        Home.Hide()
        purchase.Hide()
        Funds.Hide()
        portfolio.Show()
        stocksale.Hide()
    End Sub

    Private Sub GunaGradientButton3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton3.Click
        Me.Show()
        Home.Hide()
        purchase.Hide()
        Funds.Hide()
        portfolio.Hide()
        stocksale.Hide()
    End Sub

    Private Sub GunaGradientButton4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton4.Click
        Me.Hide()
        Home.Hide()
        purchase.Show()
        Funds.Hide()
        portfolio.Hide()
        stocksale.Hide()
    End Sub

    Private Sub GunaGradientButton5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton5.Click
        Me.Hide()
        Home.Hide()
        purchase.Hide()
        Funds.Hide()
        portfolio.Hide()
        stocksale.Show()
    End Sub

    Private Sub GunaGradientButton6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton6.Click
        Me.Hide()
        Home.Hide()
        purchase.Hide()
        Funds.Show()
        portfolio.Hide()
        stocksale.Hide()
    End Sub
End Class
﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Login
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.GunaElipse1 = New Guna.UI.WinForms.GunaElipse(Me.components)
        Me.User = New Guna.UI.WinForms.GunaTextBox()
        Me.GunaGroupBox1 = New Guna.UI.WinForms.GunaGroupBox()
        Me.GunaLabel5 = New Guna.UI.WinForms.GunaLabel()
        Me.GunaLabel4 = New Guna.UI.WinForms.GunaLabel()
        Me.GunaCheckBox1 = New Guna.UI.WinForms.GunaCheckBox()
        Me.GunaButton1 = New Guna.UI.WinForms.GunaButton()
        Me.GunaLabel3 = New Guna.UI.WinForms.GunaLabel()
        Me.Btnlogin = New Guna.UI.WinForms.GunaGradientButton()
        Me.GunaLabel2 = New Guna.UI.WinForms.GunaLabel()
        Me.GunaGoogleSwitch1 = New Guna.UI.WinForms.GunaGoogleSwitch()
        Me.GunaLabel1 = New Guna.UI.WinForms.GunaLabel()
        Me.Pass = New Guna.UI.WinForms.GunaTextBox()
        Me.GunaPictureBox2 = New Guna.UI.WinForms.GunaPictureBox()
        Me.GunaPictureBox1 = New Guna.UI.WinForms.GunaPictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GunaGroupBox1.SuspendLayout()
        CType(Me.GunaPictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GunaPictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GunaElipse1
        '
        Me.GunaElipse1.Radius = 10
        Me.GunaElipse1.TargetControl = Me
        '
        'User
        '
        Me.User.BackColor = System.Drawing.Color.Transparent
        Me.User.BaseColor = System.Drawing.Color.White
        Me.User.BorderColor = System.Drawing.Color.Silver
        Me.User.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.User.FocusedBaseColor = System.Drawing.Color.White
        Me.User.FocusedBorderColor = System.Drawing.Color.Black
        Me.User.FocusedForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.User.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.User.ForeColor = System.Drawing.SystemColors.ButtonShadow
        Me.User.Location = New System.Drawing.Point(46, 86)
        Me.User.Name = "User"
        Me.User.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.User.Radius = 5
        Me.User.SelectedText = ""
        Me.User.Size = New System.Drawing.Size(160, 30)
        Me.User.TabIndex = 1
        '
        'GunaGroupBox1
        '
        Me.GunaGroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GunaGroupBox1.BaseColor = System.Drawing.Color.White
        Me.GunaGroupBox1.BorderColor = System.Drawing.Color.Gainsboro
        Me.GunaGroupBox1.Controls.Add(Me.GunaLabel5)
        Me.GunaGroupBox1.Controls.Add(Me.GunaLabel4)
        Me.GunaGroupBox1.Controls.Add(Me.GunaCheckBox1)
        Me.GunaGroupBox1.Controls.Add(Me.GunaButton1)
        Me.GunaGroupBox1.Controls.Add(Me.GunaLabel3)
        Me.GunaGroupBox1.Controls.Add(Me.Btnlogin)
        Me.GunaGroupBox1.Controls.Add(Me.GunaLabel2)
        Me.GunaGroupBox1.Controls.Add(Me.GunaGoogleSwitch1)
        Me.GunaGroupBox1.Controls.Add(Me.GunaLabel1)
        Me.GunaGroupBox1.Controls.Add(Me.Pass)
        Me.GunaGroupBox1.Controls.Add(Me.GunaPictureBox2)
        Me.GunaGroupBox1.Controls.Add(Me.User)
        Me.GunaGroupBox1.Controls.Add(Me.GunaPictureBox1)
        Me.GunaGroupBox1.LineColor = System.Drawing.Color.Transparent
        Me.GunaGroupBox1.Location = New System.Drawing.Point(414, 12)
        Me.GunaGroupBox1.Name = "GunaGroupBox1"
        Me.GunaGroupBox1.Size = New System.Drawing.Size(256, 328)
        Me.GunaGroupBox1.TabIndex = 0
        Me.GunaGroupBox1.TextLocation = New System.Drawing.Point(10, 8)
        '
        'GunaLabel5
        '
        Me.GunaLabel5.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaLabel5.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.GunaLabel5.Location = New System.Drawing.Point(89, 136)
        Me.GunaLabel5.Name = "GunaLabel5"
        Me.GunaLabel5.Size = New System.Drawing.Size(119, 23)
        Me.GunaLabel5.TabIndex = 12
        Me.GunaLabel5.Text = "Password"
        '
        'GunaLabel4
        '
        Me.GunaLabel4.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaLabel4.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.GunaLabel4.Location = New System.Drawing.Point(89, 60)
        Me.GunaLabel4.Name = "GunaLabel4"
        Me.GunaLabel4.Size = New System.Drawing.Size(119, 23)
        Me.GunaLabel4.TabIndex = 11
        Me.GunaLabel4.Text = "Username"
        '
        'GunaCheckBox1
        '
        Me.GunaCheckBox1.BackColor = System.Drawing.Color.Gray
        Me.GunaCheckBox1.BaseColor = System.Drawing.Color.Gray
        Me.GunaCheckBox1.CheckedOffColor = System.Drawing.Color.Gray
        Me.GunaCheckBox1.CheckedOnColor = System.Drawing.Color.Lime
        Me.GunaCheckBox1.FillColor = System.Drawing.Color.Gray
        Me.GunaCheckBox1.Location = New System.Drawing.Point(177, 167)
        Me.GunaCheckBox1.Name = "GunaCheckBox1"
        Me.GunaCheckBox1.Radius = 3
        Me.GunaCheckBox1.Size = New System.Drawing.Size(20, 20)
        Me.GunaCheckBox1.TabIndex = 10
        '
        'GunaButton1
        '
        Me.GunaButton1.AnimationHoverSpeed = 0.07!
        Me.GunaButton1.AnimationSpeed = 0.03!
        Me.GunaButton1.BackColor = System.Drawing.Color.Transparent
        Me.GunaButton1.BaseColor = System.Drawing.Color.Silver
        Me.GunaButton1.BorderColor = System.Drawing.Color.Black
        Me.GunaButton1.BorderSize = 1
        Me.GunaButton1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaButton1.FocusedColor = System.Drawing.Color.Black
        Me.GunaButton1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaButton1.ForeColor = System.Drawing.Color.Black
        Me.GunaButton1.Image = Global._309_BhandariPrince_stock_managment_system.My.Resources.Resources.arrow1
        Me.GunaButton1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.GunaButton1.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaButton1.Location = New System.Drawing.Point(46, 288)
        Me.GunaButton1.Name = "GunaButton1"
        Me.GunaButton1.OnHoverBaseColor = System.Drawing.Color.DimGray
        Me.GunaButton1.OnHoverBorderColor = System.Drawing.Color.White
        Me.GunaButton1.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaButton1.OnHoverImage = Nothing
        Me.GunaButton1.OnPressedColor = System.Drawing.Color.Black
        Me.GunaButton1.Radius = 8
        Me.GunaButton1.Size = New System.Drawing.Size(173, 40)
        Me.GunaButton1.TabIndex = 1
        Me.GunaButton1.Text = "Create Account"
        Me.GunaButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GunaLabel3
        '
        Me.GunaLabel3.AutoSize = True
        Me.GunaLabel3.BackColor = System.Drawing.Color.White
        Me.GunaLabel3.Font = New System.Drawing.Font("Segoe UI Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaLabel3.ForeColor = System.Drawing.Color.DimGray
        Me.GunaLabel3.Location = New System.Drawing.Point(30, 268)
        Me.GunaLabel3.Name = "GunaLabel3"
        Me.GunaLabel3.Size = New System.Drawing.Size(205, 17)
        Me.GunaLabel3.TabIndex = 1
        Me.GunaLabel3.Text = "Forgot Username or Password?"
        '
        'Btnlogin
        '
        Me.Btnlogin.AnimationHoverSpeed = 0.07!
        Me.Btnlogin.AnimationSpeed = 0.03!
        Me.Btnlogin.BackColor = System.Drawing.Color.Transparent
        Me.Btnlogin.BaseColor1 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Btnlogin.BaseColor2 = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Btnlogin.BorderColor = System.Drawing.Color.Black
        Me.Btnlogin.BorderSize = 2
        Me.Btnlogin.DialogResult = System.Windows.Forms.DialogResult.None
        Me.Btnlogin.FocusedColor = System.Drawing.Color.Empty
        Me.Btnlogin.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btnlogin.ForeColor = System.Drawing.Color.Black
        Me.Btnlogin.Image = Global._309_BhandariPrince_stock_managment_system.My.Resources.Resources.use_log
        Me.Btnlogin.ImageSize = New System.Drawing.Size(20, 20)
        Me.Btnlogin.Location = New System.Drawing.Point(59, 228)
        Me.Btnlogin.Name = "Btnlogin"
        Me.Btnlogin.OnHoverBaseColor1 = System.Drawing.Color.FromArgb(CType(CType(155, Byte), Integer), CType(CType(145, Byte), Integer), CType(CType(221, Byte), Integer))
        Me.Btnlogin.OnHoverBaseColor2 = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Btnlogin.OnHoverBorderColor = System.Drawing.Color.Black
        Me.Btnlogin.OnHoverForeColor = System.Drawing.Color.White
        Me.Btnlogin.OnHoverImage = Nothing
        Me.Btnlogin.OnPressedColor = System.Drawing.Color.Black
        Me.Btnlogin.Radius = 15
        Me.Btnlogin.Size = New System.Drawing.Size(135, 34)
        Me.Btnlogin.TabIndex = 9
        Me.Btnlogin.Text = "LOGIN"
        Me.Btnlogin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GunaLabel2
        '
        Me.GunaLabel2.AutoSize = True
        Me.GunaLabel2.BackColor = System.Drawing.Color.White
        Me.GunaLabel2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaLabel2.ForeColor = System.Drawing.Color.DimGray
        Me.GunaLabel2.Location = New System.Drawing.Point(85, 198)
        Me.GunaLabel2.Name = "GunaLabel2"
        Me.GunaLabel2.Size = New System.Drawing.Size(121, 21)
        Me.GunaLabel2.TabIndex = 7
        Me.GunaLabel2.Text = "Remember Me"
        '
        'GunaGoogleSwitch1
        '
        Me.GunaGoogleSwitch1.BaseColor = System.Drawing.SystemColors.Control
        Me.GunaGoogleSwitch1.CheckedOffColor = System.Drawing.Color.DarkGray
        Me.GunaGoogleSwitch1.CheckedOnColor = System.Drawing.Color.Lime
        Me.GunaGoogleSwitch1.FillColor = System.Drawing.Color.White
        Me.GunaGoogleSwitch1.Location = New System.Drawing.Point(45, 198)
        Me.GunaGoogleSwitch1.Name = "GunaGoogleSwitch1"
        Me.GunaGoogleSwitch1.Size = New System.Drawing.Size(38, 20)
        Me.GunaGoogleSwitch1.TabIndex = 6
        '
        'GunaLabel1
        '
        Me.GunaLabel1.AutoSize = True
        Me.GunaLabel1.BackColor = System.Drawing.Color.White
        Me.GunaLabel1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GunaLabel1.Location = New System.Drawing.Point(85, 11)
        Me.GunaLabel1.Name = "GunaLabel1"
        Me.GunaLabel1.Size = New System.Drawing.Size(91, 21)
        Me.GunaLabel1.TabIndex = 5
        Me.GunaLabel1.Text = "User Login"
        '
        'Pass
        '
        Me.Pass.BackColor = System.Drawing.Color.Transparent
        Me.Pass.BaseColor = System.Drawing.Color.White
        Me.Pass.BorderColor = System.Drawing.Color.Silver
        Me.Pass.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Pass.FocusedBaseColor = System.Drawing.Color.White
        Me.Pass.FocusedBorderColor = System.Drawing.Color.Black
        Me.Pass.FocusedForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Pass.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pass.ForeColor = System.Drawing.SystemColors.ButtonShadow
        Me.Pass.Location = New System.Drawing.Point(46, 162)
        Me.Pass.Name = "Pass"
        Me.Pass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Pass.Radius = 5
        Me.Pass.SelectedText = ""
        Me.Pass.Size = New System.Drawing.Size(160, 30)
        Me.Pass.TabIndex = 4
        '
        'GunaPictureBox2
        '
        Me.GunaPictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.GunaPictureBox2.BaseColor = System.Drawing.Color.White
        Me.GunaPictureBox2.Image = Global._309_BhandariPrince_stock_managment_system.My.Resources.Resources.locked1
        Me.GunaPictureBox2.Location = New System.Drawing.Point(48, 129)
        Me.GunaPictureBox2.Name = "GunaPictureBox2"
        Me.GunaPictureBox2.Radius = 5
        Me.GunaPictureBox2.Size = New System.Drawing.Size(37, 30)
        Me.GunaPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.GunaPictureBox2.TabIndex = 3
        Me.GunaPictureBox2.TabStop = False
        '
        'GunaPictureBox1
        '
        Me.GunaPictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.GunaPictureBox1.BaseColor = System.Drawing.Color.White
        Me.GunaPictureBox1.Image = Global._309_BhandariPrince_stock_managment_system.My.Resources.Resources.logo_of_user
        Me.GunaPictureBox1.Location = New System.Drawing.Point(48, 60)
        Me.GunaPictureBox1.Name = "GunaPictureBox1"
        Me.GunaPictureBox1.Radius = 5
        Me.GunaPictureBox1.Size = New System.Drawing.Size(35, 23)
        Me.GunaPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.GunaPictureBox1.TabIndex = 2
        Me.GunaPictureBox1.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global._309_BhandariPrince_stock_managment_system.My.Resources.Resources.login_logo6
        Me.PictureBox1.Location = New System.Drawing.Point(12, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(396, 328)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Login
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(758, 366)
        Me.Controls.Add(Me.GunaGroupBox1)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Login"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Login"
        Me.GunaGroupBox1.ResumeLayout(False)
        Me.GunaGroupBox1.PerformLayout()
        CType(Me.GunaPictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GunaPictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents GunaElipse1 As Guna.UI.WinForms.GunaElipse
    Friend WithEvents GunaPictureBox1 As Guna.UI.WinForms.GunaPictureBox
    Friend WithEvents User As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents GunaGroupBox1 As Guna.UI.WinForms.GunaGroupBox
    Friend WithEvents Pass As Guna.UI.WinForms.GunaTextBox
    Friend WithEvents GunaPictureBox2 As Guna.UI.WinForms.GunaPictureBox
    Friend WithEvents GunaLabel2 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents GunaGoogleSwitch1 As Guna.UI.WinForms.GunaGoogleSwitch
    Friend WithEvents GunaLabel1 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents GunaLabel3 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents Btnlogin As Guna.UI.WinForms.GunaGradientButton
    Friend WithEvents GunaButton1 As Guna.UI.WinForms.GunaButton
    Friend WithEvents GunaCheckBox1 As Guna.UI.WinForms.GunaCheckBox
    Friend WithEvents GunaLabel5 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents GunaLabel4 As Guna.UI.WinForms.GunaLabel
End Class

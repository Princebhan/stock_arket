﻿Public Class Loading

    Private Sub GunaButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaButton2.Click
        Caccount.Show()
        Me.Hide()
    End Sub

    Private Sub GunaButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaButton1.Click
        Login.Show()
        Me.Hide()
    End Sub

    Private Sub GunaGradientButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GunaGradientButton1.Click
        MsgBox("Insta Id = prince_.022", MsgBoxStyle.Exclamation)

    End Sub

    
    
End Class

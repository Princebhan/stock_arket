﻿Imports System.Data.OleDb
Imports System.Data.OleDb.OleDbPermission
Imports System.Math

Public Class path

    Public constring As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Prince\Documents\Visual Studio 2010\Projects\309_BhandariPrince_stock_managment_system\pjt_sms.accdb"
    Public con As New OleDbConnection(constring)



End Class
